import BlogPage, { getStaticProps } from './page/[page]'

export default BlogPage

export { getStaticProps }
