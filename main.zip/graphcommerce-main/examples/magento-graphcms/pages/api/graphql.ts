import { createServer } from '@graphcommerce/graphql-mesh'

export default await createServer('/api/graphql')
