declare module '*.yml' {
  const content: unknown
  export default content
}
