# GraphCommerce CLI

Commands:

```
# https://www.graphql-mesh.com/docs/getting-started/deploy-mesh-gateway
yarn mesh build
```
