# GraphQL generation package, used by other packages.
