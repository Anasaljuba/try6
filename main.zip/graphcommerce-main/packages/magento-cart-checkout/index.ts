export * from './queries/CartPage.gql'
export * from './queries/ShippingPage.gql'
export * from './queries/BillingPage.gql'
