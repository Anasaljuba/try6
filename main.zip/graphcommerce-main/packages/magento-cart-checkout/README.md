# Magento Cart Checkout

The default implementation of the GraphCommerce checkoutprocess.

- All Pages
- Cart Page
- Shipping Page
- Payment Page
- Success Page
