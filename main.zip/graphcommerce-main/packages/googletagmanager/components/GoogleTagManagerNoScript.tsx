/** @deprecated Not needed anymore, please use the GoogleTagManagerScript component in your _app. */
export function GoogleTagManagerNoScript() {
  return null
}
