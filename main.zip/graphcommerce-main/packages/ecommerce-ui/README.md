# ecommerce-ui

Package to connect generic components from `@graphcommerce/next-ui` to
`@graphcommerce/react-hook-form` and `@graphcommerce/graphql`
