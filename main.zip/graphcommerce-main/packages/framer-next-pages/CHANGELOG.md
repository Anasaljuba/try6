# Change Log

## 5.0.0

### Major Changes

- [#1734](https://github.com/graphcommerce-org/graphcommerce/pull/1734) [`e4c7fe17e`](https://github.com/graphcommerce-org/graphcommerce/commit/e4c7fe17e413e37362ceae92e67f1b3a5f62d398) - Bump major version of all packages ([@github-actions](https://github.com/apps/github-actions))

### Patch Changes

- [#1734](https://github.com/graphcommerce-org/graphcommerce/pull/1734) [`f44dae2c5`](https://github.com/graphcommerce-org/graphcommerce/commit/f44dae2c5a82e62dc8b3f08ad672278faa1c9f54) - When rendering the page it should run the initial animations if a page doesn't want to do that it should disable initial it's self ([@github-actions](https://github.com/apps/github-actions))

## 5.0.0-canary.14

## 5.0.0-canary.9

### Major Changes

- [`e4c7fe17e`](https://github.com/graphcommerce-org/graphcommerce/commit/e4c7fe17e413e37362ceae92e67f1b3a5f62d398) - Bump major version of all packages ([@paales](https://github.com/paales))

## 4.31.0-canary.8

### Patch Changes

- [`f44dae2c5`](https://github.com/graphcommerce-org/graphcommerce/commit/f44dae2c5a82e62dc8b3f08ad672278faa1c9f54) - When rendering the page it should run the initial animations if a page doesn't want to do that it should disable initial it's self ([@paales](https://github.com/paales))

## 4.31.0-canary.7

## 4.31.0-canary.6

## 4.31.0-canary.5

## 4.31.0-canary.4

## 4.31.0-canary.3

## 4.31.0-canary.2

## 4.31.0-canary.1

## 4.31.0-canary.0

## 4.30.2

## 4.30.1

## 4.30.0

### Patch Changes

- [#1702](https://github.com/graphcommerce-org/graphcommerce/pull/1702) [`abb15ef4a`](https://github.com/graphcommerce-org/graphcommerce/commit/abb15ef4a79b12eddb32cc006e5d1d31dd06ac2d) Thanks [@paales](https://github.com/paales)! - Added canary releases to GraphCommerce

## 4.30.0-canary.1

### Patch Changes

- [`abb15ef4a`](https://github.com/graphcommerce-org/graphcommerce/commit/abb15ef4a79b12eddb32cc006e5d1d31dd06ac2d) Thanks [@paales](https://github.com/paales)! - Added canary releases to GraphCommerce

## 4.30.0-canary.0

## 3.3.2

### Patch Changes

- Updated dependencies [[`1b1504c9b`](https://github.com/graphcommerce-org/graphcommerce/commit/1b1504c9b0e51f2787bce91e1ff1940f540411d6), [`6c2e27b1b`](https://github.com/graphcommerce-org/graphcommerce/commit/6c2e27b1be4aaa888e65a2bd69eaeb467a54a023)]:
  - @graphcommerce/framer-utils@3.2.1

## 3.3.1

### Patch Changes

- [#1662](https://github.com/graphcommerce-org/graphcommerce/pull/1662) [`9e0ca73eb`](https://github.com/graphcommerce-org/graphcommerce/commit/9e0ca73eb50ded578f4a98e40a7eb920bf8ab421) Thanks [@paales](https://github.com/paales)! - Export additional usePrevPageRouter

## 3.3.0

### Minor Changes

- [#1602](https://github.com/graphcommerce-org/graphcommerce/pull/1602) [`5f781a217`](https://github.com/graphcommerce-org/graphcommerce/commit/5f781a217ce63ed56bc1a9983487b04400a8a315) Thanks [@ErwinOtten](https://github.com/ErwinOtten)! - Default styles and layout fixes

  - Scaled icons and fonts down. Size in typography is now more gradual: https://graphcommerce.vercel.app/test/typography
  - Multiple accessibility fixes. Missing button/input labels, and fixed spacing issues resulting in high % appropriately sized tap targets
  - Replaced responsiveVal usage with better performaning breakpointVal where possible
  - All buttons are now Pill by default.
  - Cleaned up checkout styles

### Patch Changes

- Updated dependencies [[`01372b918`](https://github.com/graphcommerce-org/graphcommerce/commit/01372b918a291e01cbf5db40edcb40fb1c2af313)]:
  - @graphcommerce/framer-utils@3.2.0

## 3.2.5

### Patch Changes

- Updated dependencies [[`707dbc73d`](https://github.com/graphcommerce-org/graphcommerce/commit/707dbc73d181204d88fdbbd2e09340e25b2b5f7b), [`5c5645e6e`](https://github.com/graphcommerce-org/graphcommerce/commit/5c5645e6eaf5314c063f05547707fcd4b34a8717)]:
  - @graphcommerce/framer-utils@3.1.5

## 3.2.4

### Patch Changes

- [#1552](https://github.com/graphcommerce-org/graphcommerce/pull/1552) [`18054c441`](https://github.com/graphcommerce-org/graphcommerce/commit/18054c441962ba750bed3acc39ab46c8d3a341ce) Thanks [@paales](https://github.com/paales)! - Updated to Next.js v12.2.2 and other packages and made compatible

* [#1552](https://github.com/graphcommerce-org/graphcommerce/pull/1552) [`21886d6fa`](https://github.com/graphcommerce-org/graphcommerce/commit/21886d6fa64a48d9e932bfaf8d138c9b13c36e43) Thanks [@paales](https://github.com/paales)! - Fix page stacking and scroll restoration when navigating

## 3.2.3

### Patch Changes

- [#1490](https://github.com/graphcommerce-org/graphcommerce/pull/1490) [`d311ef48b`](https://github.com/graphcommerce-org/graphcommerce/commit/d311ef48bb3e97806d992af5516d6b7f183ec9cb) Thanks [@paales](https://github.com/paales)! - upgraded packages

- Updated dependencies [[`d311ef48b`](https://github.com/graphcommerce-org/graphcommerce/commit/d311ef48bb3e97806d992af5516d6b7f183ec9cb)]:
  - @graphcommerce/framer-utils@3.1.4

## 3.2.2

### Patch Changes

- [#1477](https://github.com/graphcommerce-org/graphcommerce/pull/1477) [`597e2f413`](https://github.com/graphcommerce-org/graphcommerce/commit/597e2f413bdb5b76793b40ab631ce61390e26e81) Thanks [@paales](https://github.com/paales)! - fixes Received `true` for a non-boolean attribute `inert`.

- Updated dependencies [[`f167f9963`](https://github.com/graphcommerce-org/graphcommerce/commit/f167f99630966a7de43717937d43669e66132494)]:
  - @graphcommerce/framer-utils@3.1.3

## 3.2.1

### Patch Changes

- [#1432](https://github.com/graphcommerce-org/graphcommerce/pull/1432) [`99600dd09`](https://github.com/graphcommerce-org/graphcommerce/commit/99600dd091980dd9ef335c04d2efac0835c20b2f) Thanks [@paales](https://github.com/paales)! - make sure the background isn’t visible to screen readers

## 3.2.0

### Minor Changes

- [#1416](https://github.com/graphcommerce-org/graphcommerce/pull/1416) [`f3d06dd83`](https://github.com/graphcommerce-org/graphcommerce/commit/f3d06dd836c9a76412b419d4d2c79bbd0ee92e04) Thanks [@ErwinOtten](https://github.com/ErwinOtten)! - SEO audit

## 3.1.6

### Patch Changes

- [#1399](https://github.com/graphcommerce-org/graphcommerce/pull/1399) [`da0ae7d02`](https://github.com/graphcommerce-org/graphcommerce/commit/da0ae7d0236e4908ba0bf0fa16656be516e841d4) Thanks [@paales](https://github.com/paales)! - Updated dependencies

- Updated dependencies [[`da0ae7d02`](https://github.com/graphcommerce-org/graphcommerce/commit/da0ae7d0236e4908ba0bf0fa16656be516e841d4)]:
  - @graphcommerce/framer-utils@3.1.2

## 3.1.5

### Patch Changes

- [#1378](https://github.com/graphcommerce-org/graphcommerce/pull/1378) [`b610a6e40`](https://github.com/graphcommerce-org/graphcommerce/commit/b610a6e4049e8c9e8b5d2aeff31b8e1bfc24abe5) Thanks [@paales](https://github.com/paales)! - Pin all versions internally so we can’t end up in an unfixable state for the user

## 3.1.4

### Patch Changes

- [#1369](https://github.com/graphcommerce-org/graphcommerce/pull/1369) [`ae6449502`](https://github.com/graphcommerce-org/graphcommerce/commit/ae64495024a455bbe5188588604368c1542840c9) Thanks [@paales](https://github.com/paales)! - Upgraded dependencies

- Updated dependencies [[`ae6449502`](https://github.com/graphcommerce-org/graphcommerce/commit/ae64495024a455bbe5188588604368c1542840c9)]:
  - @graphcommerce/framer-utils@3.1.1

## 3.1.3

### Patch Changes

- [#1363](https://github.com/graphcommerce-org/graphcommerce/pull/1363) [`c9f7ac026`](https://github.com/graphcommerce-org/graphcommerce/commit/c9f7ac026b49047eca05be208b515f364e21571c) Thanks [@paales](https://github.com/paales)! - Calling back multiple times in succession doens’t work on ipad and causes flashes on other devices. Replace with window.history.go(-x)

* [#1360](https://github.com/graphcommerce-org/graphcommerce/pull/1360) [`829b8690b`](https://github.com/graphcommerce-org/graphcommerce/commit/829b8690bc5d0a46e596299e4120e9837a9f179c) Thanks [@paales](https://github.com/paales)! - Make sure the minimum height of the viewport is at least the viewport size on mobile.

* Updated dependencies [[`829b8690b`](https://github.com/graphcommerce-org/graphcommerce/commit/829b8690bc5d0a46e596299e4120e9837a9f179c)]:
  - @graphcommerce/framer-utils@3.1.0

## 3.1.2

### Patch Changes

- [#1307](https://github.com/ho-nl/m2-pwa/pull/1307) [`bd10506d3`](https://github.com/ho-nl/m2-pwa/commit/bd10506d32fdbc91d01dadc29a12ebd1e0943655) Thanks [@paales](https://github.com/paales)! - All default exports are now named exports internally and all `index.tsx` are renamed to the component name.

* [#1307](https://github.com/ho-nl/m2-pwa/pull/1307) [`27cb1f2d8`](https://github.com/ho-nl/m2-pwa/commit/27cb1f2d8dbfb8f1b301ce56fb6a2b6c1fc6a5ef) Thanks [@paales](https://github.com/paales)! - upgrade dependencies

* Updated dependencies [[`bd10506d3`](https://github.com/ho-nl/m2-pwa/commit/bd10506d32fdbc91d01dadc29a12ebd1e0943655), [`27cb1f2d8`](https://github.com/ho-nl/m2-pwa/commit/27cb1f2d8dbfb8f1b301ce56fb6a2b6c1fc6a5ef)]:
  - @graphcommerce/framer-utils@3.0.4

## 3.1.1

### Patch Changes

- [#1294](https://github.com/ho-nl/m2-pwa/pull/1294) [`afb993244`](https://github.com/ho-nl/m2-pwa/commit/afb993244aabc8135ce54a79743cbf63bc5677d3) Thanks [@paales](https://github.com/paales)! - Make sure the fallback handles localization properly

## 3.1.0

### Minor Changes

- [#1281](https://github.com/ho-nl/m2-pwa/pull/1281) [`4bb963d75`](https://github.com/ho-nl/m2-pwa/commit/4bb963d7595b5ce6e3a4924cc2e3e8b0210cdcd6) Thanks [@paales](https://github.com/paales)! - Add an option the FramerNextPages component to define a fallback and fallbackRoute.

### Patch Changes

- [`973ff8645`](https://github.com/ho-nl/m2-pwa/commit/973ff86452a70ade9f4db13fdda6e963d7220e96) Thanks [@paales](https://github.com/paales)! - made packages public

- Updated dependencies [[`973ff8645`](https://github.com/ho-nl/m2-pwa/commit/973ff86452a70ade9f4db13fdda6e963d7220e96)]:
  - @graphcommerce/framer-utils@3.0.3

## 3.0.2

### Patch Changes

- [#1274](https://github.com/ho-nl/m2-pwa/pull/1274) [`381e4c86a`](https://github.com/ho-nl/m2-pwa/commit/381e4c86a8321ce96e1fa5c7d3c0a0c0ff3e02c7) Thanks [@paales](https://github.com/paales)! - Moved `ApolloErrorAlert`, `ApolloErrorFullPage` and `ApolloErrorSnackbar` to the ecommerce-ui package.

  Created `ComposedSubmitButton` and `ComposedSubmitLinkOrButton` to reduce complexity from `magento-graphcms` example.

  Removed dependency an `@graphcommerce/react-hook-form` from `magento-graphcms` example.

  Added dependency `@graphcommerce/ecommerce-ui` from `magento-graphcms` example.

* [#1276](https://github.com/ho-nl/m2-pwa/pull/1276) [`ce09388e0`](https://github.com/ho-nl/m2-pwa/commit/ce09388e0d7ef33aee660612340f6fbae15ceec2) Thanks [@paales](https://github.com/paales)! - We've moved lots of internal packages from `dependencies` to `peerDependencies`. The result of this is that there will be significantly less duplicate packages in the node_modules folders.

- [#1276](https://github.com/ho-nl/m2-pwa/pull/1276) [`52a45bba4`](https://github.com/ho-nl/m2-pwa/commit/52a45bba4dc6dd6df3c81f5023df7d23ed8a534d) Thanks [@paales](https://github.com/paales)! - Upgraded to [NextJS 12.1](https://nextjs.org/blog/next-12-1)! This is just for compatibility, but we'll be implementing [On-demand Incremental Static Regeneration](https://nextjs.org/blog/next-12-1#on-demand-incremental-static-regeneration-beta) soon.

  This will greatly reduce the requirement to rebuid stuff and we'll add a management UI on the frontend to be able to revalidate pages manually.

- Updated dependencies [[`ce09388e0`](https://github.com/ho-nl/m2-pwa/commit/ce09388e0d7ef33aee660612340f6fbae15ceec2), [`52a45bba4`](https://github.com/ho-nl/m2-pwa/commit/52a45bba4dc6dd6df3c81f5023df7d23ed8a534d)]:
  - @graphcommerce/framer-utils@3.0.2

## 3.0.1

### Patch Changes

- [`0cbaa878b`](https://github.com/ho-nl/m2-pwa/commit/0cbaa878b8a844d5abbeb1797b625a33130e6514) Thanks [@paales](https://github.com/paales)! - Added homepage and repository package.json files, so that the packages link to back to the website and repository
- Updated dependencies [[`0cbaa878b`](https://github.com/ho-nl/m2-pwa/commit/0cbaa878b8a844d5abbeb1797b625a33130e6514)]:
  - @graphcommerce/framer-utils@3.0.1

## 3.0.0

### Major Changes

- [#1258](https://github.com/ho-nl/m2-pwa/pull/1258) [`ad36382a4`](https://github.com/ho-nl/m2-pwa/commit/ad36382a4d55d83d9e47b7eb6a02671a2a631a05) Thanks [@paales](https://github.com/paales)! - Upgraded to Material UI 5

### Patch Changes

- Updated dependencies [[`ad36382a4`](https://github.com/ho-nl/m2-pwa/commit/ad36382a4d55d83d9e47b7eb6a02671a2a631a05)]:
  - @graphcommerce/framer-utils@3.0.0

All notable changes to this project will be documented in this file. See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## [2.109.2](https://github.com/ho-nl/m2-pwa/compare/@graphcommerce/framer-next-pages@2.109.1...@graphcommerce/framer-next-pages@2.109.2) (2022-01-04)

### Bug Fixes

- regression where close button didn't work ([5bf57b4](https://github.com/ho-nl/m2-pwa/commit/5bf57b470ab7c013fbe0a896792fcb316a454aa4))

# [2.109.0](https://github.com/ho-nl/m2-pwa/compare/@graphcommerce/framer-next-pages@2.108.11...@graphcommerce/framer-next-pages@2.109.0) (2022-01-03)

### Features

- **framer-next-pages:** reduce rerenders when navigating to a new page ([5cf3301](https://github.com/ho-nl/m2-pwa/commit/5cf330130bb3527057da015e3c4a6fa295d7262e))

## [2.108.10](https://github.com/ho-nl/m2-pwa/compare/@graphcommerce/framer-next-pages@2.108.9...@graphcommerce/framer-next-pages@2.108.10) (2021-12-23)

### Bug Fixes

- **framer-next-pages:** closing is janky, caused by setting pointer-events to none, trying without resetting the pointerevents ([9247fa3](https://github.com/ho-nl/m2-pwa/commit/9247fa312926416802abd68ea04b1e6b52531f2c))

## [2.108.8](https://github.com/ho-nl/m2-pwa/compare/@graphcommerce/framer-next-pages@2.108.7...@graphcommerce/framer-next-pages@2.108.8) (2021-12-21)

### Bug Fixes

- **graphql:** make sure we're passing the correct store code to the schema endpoint ([39753f2](https://github.com/ho-nl/m2-pwa/commit/39753f2117ce7ba79dab035c4134e642829e7f18))
- make sure we're remounting when the store changes ([10756e3](https://github.com/ho-nl/m2-pwa/commit/10756e3eb252f8a91d84534ae024edb382a4ea0d))

## [2.108.7](https://github.com/ho-nl/m2-pwa/compare/@graphcommerce/framer-next-pages@2.108.6...@graphcommerce/framer-next-pages@2.108.7) (2021-12-20)

### Bug Fixes

- animations would run on background page, make sure animations are not running when page is not active ([2fcf4b8](https://github.com/ho-nl/m2-pwa/commit/2fcf4b8a853108147477e3a67c7ea202abb2842f))

## [2.108.3](https://github.com/ho-nl/m2-pwa/compare/@graphcommerce/framer-next-pages@2.108.2...@graphcommerce/framer-next-pages@2.108.3) (2021-12-15)

### Bug Fixes

- **framer-next-pages:** make sure the cancellation of loading the fallback doesn't show an error ([3470461](https://github.com/ho-nl/m2-pwa/commit/34704612c7b19a61a8309967b982e5f04c0fe8b2))

## [2.108.2](https://github.com/ho-nl/m2-pwa/compare/@graphcommerce/framer-next-pages@2.108.1...@graphcommerce/framer-next-pages@2.108.2) (2021-12-13)

### Bug Fixes

- make sure we're using the correct variant ([7fff606](https://github.com/ho-nl/m2-pwa/commit/7fff606390bc63c14cd8c033fbe5138226517869))

# [2.108.0](https://github.com/ho-nl/m2-pwa/compare/@graphcommerce/framer-next-pages@2.107.5...@graphcommerce/framer-next-pages@2.108.0) (2021-12-03)

### Bug Fixes

- **framer-next-pages:** do no throw error when framer next pages is recreated ([6c4665b](https://github.com/ho-nl/m2-pwa/commit/6c4665b4a00adb1c1d770c458a590f4360be83d8))
- make sure the fallback loads during idle timing to prevent jank ([dd888e2](https://github.com/ho-nl/m2-pwa/commit/dd888e27b94091233d74ddba1023310b09910f0f))
- make sure the overlay becomes visible, even if the overlay is scrolled ([1738c98](https://github.com/ho-nl/m2-pwa/commit/1738c982ea84ec2b93daa824c4b8c86ab2a3f5ed))
- make sure the overlays are rendered correctly on mobile ([48f7050](https://github.com/ho-nl/m2-pwa/commit/48f705060e99b997f5b1db03ccc49f1051a1ed8f))
- minHeight of page on iOS is sometimes less high than expected ([8a0bc23](https://github.com/ho-nl/m2-pwa/commit/8a0bc234d153d974ac415369483ddabfb5e7fb0c))
- spacing of LayoutTItle ([7afcd31](https://github.com/ho-nl/m2-pwa/commit/7afcd3163d16e902cf2ff7917f56ee6a8798f55b))

### Features

- **framer-next-pages:** automatically create a fallback page when there is no page to render. ([f18a804](https://github.com/ho-nl/m2-pwa/commit/f18a804a228901431f848927844dd9cd324170c1))

## [2.107.3](https://github.com/ho-nl/m2-pwa/compare/@graphcommerce/framer-next-pages@2.107.2...@graphcommerce/framer-next-pages@2.107.3) (2021-11-02)

### Bug Fixes

- **framer-next-pages:** prevent back button loop when previous page is the up page of the previous page ([cbdde83](https://github.com/ho-nl/m2-pwa/commit/cbdde83790337bdf4c5f03c907ca6e6e02792e70))

# [2.107.0](https://github.com/ho-nl/m2-pwa/compare/@graphcommerce/framer-next-pages@2.106.12...@graphcommerce/framer-next-pages@2.107.0) (2021-10-27)

### Features

- **nextjs:** upgraded to nextjs 12 ([9331bc8](https://github.com/ho-nl/m2-pwa/commit/9331bc801f6419522115cc47d291d49d608d5a90))

## [2.106.2](https://github.com/ho-nl/m2-pwa/compare/@graphcommerce/framer-next-pages@2.106.0...@graphcommerce/framer-next-pages@2.106.2) (2021-09-27)

### Bug Fixes

- ignore example directories when publishing ([620cbb2](https://github.com/ho-nl/m2-pwa/commit/620cbb2d8e68b727b8593e2e45702c4d12276d92))
- versions ([b8b306c](https://github.com/ho-nl/m2-pwa/commit/b8b306c8f3a13415e441d0593c638ae2a3731cd6))

## [2.106.1](https://github.com/ho-nl/m2-pwa/compare/@graphcommerce/framer-next-pages@2.106.0...@graphcommerce/framer-next-pages@2.106.1) (2021-09-27)

**Note:** Version bump only for package @graphcommerce/framer-next-pages

# Change Log

All notable changes to this project will be documented in this file. See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

# 2.106.0 (2021-09-27)

### Bug Fixes

- **app-shell-header:** offset not always correctly set ([11a8907](https://github.com/ho-nl/m2-pwa/commit/11a890764be1ab4f6c584a5c8ca4e6620d0d73e5))
- back button behavior ([59f7b20](https://github.com/ho-nl/m2-pwa/commit/59f7b2047194c3506037fc88d791302c7c4a1a69))
- edit billing address updating state ([ecd9f48](https://github.com/ho-nl/m2-pwa/commit/ecd9f48ce313d8e7a698c06ff29b88231dc50168))
- **framer-next-pages:** back navigation renders the wrong page, items were reversed ([7168fc1](https://github.com/ho-nl/m2-pwa/commit/7168fc1d1daa3920ae401dda0029e35a253068ec))
- **framer-next-pages:** backSteps returns NaN ([31ac95a](https://github.com/ho-nl/m2-pwa/commit/31ac95a75fb166efdc2d52d0aa0e40e45290e6bb))
- **framer-next-pages:** better opening handling of sheets ([ab5b7d1](https://github.com/ho-nl/m2-pwa/commit/ab5b7d155df65f9e4ffa21b8c676eaf4be894f3a))
- **framer-next-pages:** do not render initial animation ([6debfbf](https://github.com/ho-nl/m2-pwa/commit/6debfbfa21fd6b14ee3ff80b388b9008d2901f43))
- **framer-next-pages:** fix closing of overlay in example ([049a9a7](https://github.com/ho-nl/m2-pwa/commit/049a9a79f882bcf6251fc24cb395b88418349557))
- **framer-next-pages:** give back control to previous page as soon as possible ([4870925](https://github.com/ho-nl/m2-pwa/commit/4870925554cfee3ac94209719d9464b82fce9cc5))
- **framer-next-pages:** overlay offset fixes ([1b45cc8](https://github.com/ho-nl/m2-pwa/commit/1b45cc85412c17a4a02ae6a3bad23808def6cbfc))
- **framer-next-pages:** prevent unessary rerender when navigating back to a previous page ([a5568d0](https://github.com/ho-nl/m2-pwa/commit/a5568d00a034ef0686bd36b548af1def93ad1522))
- **framer-next-pages:** router proxy couldn’t fall back to home ([7644698](https://github.com/ho-nl/m2-pwa/commit/76446981898e7573148ad71d496ef5bafc1232b8))
- **framer-next-pages:** set height of container properly on mobile ([a91728d](https://github.com/ho-nl/m2-pwa/commit/a91728d087a557800110477691704b6918ddf35c))
- **framer-next-pages:** stacking order becomes reversed ([65bda4e](https://github.com/ho-nl/m2-pwa/commit/65bda4e8df199d805da6edc12ba61badf56eac8f))
- **framer-next-page:** usePageRouter in SharedLayout ([c2fb164](https://github.com/ho-nl/m2-pwa/commit/c2fb164b342770089b787378a3f79529c36d2152))
- **framer-sheet:** left/rigth sheet is a little higher than the page ([4c4679d](https://github.com/ho-nl/m2-pwa/commit/4c4679d00de1e3306aa0587ad9f9f10df8e2324a))
- **framer-sheet:** make opacity animation of SheetBackdrop less jarring when dragging fast ([f25b7ce](https://github.com/ho-nl/m2-pwa/commit/f25b7ce2a16a621799a434704ed77b59089808cb))
- **framer-sheet:** make sure the left/right drawer have more space / better scrollbar ([226387a](https://github.com/ho-nl/m2-pwa/commit/226387a5e7b9b8a93f9516c97879be959b8072dc))
- ignore md files from triggering version updates ([4f98392](https://github.com/ho-nl/m2-pwa/commit/4f9839250b3a32d3070da5290e5efcc5e2243fba))
- make packages private so they dont get published accidently ([f7b693f](https://github.com/ho-nl/m2-pwa/commit/f7b693ff6a4d232d0871f6a68922d14678853a96))
- performance of overlays on firefox ([46d256d](https://github.com/ho-nl/m2-pwa/commit/46d256dc611eb0eb9b9b01e7cd9d99845ef3b6da))
- **use-back-link:** pop history after going back ([20d69ef](https://github.com/ho-nl/m2-pwa/commit/20d69eff868d53d07084e5d1f78819939a5f429c))

### Features

- ability to add a fallback ([470110c](https://github.com/ho-nl/m2-pwa/commit/470110c82c1de15954570aa28dc3f81048ae1ca1))
- content header component ([9cf58cd](https://github.com/ho-nl/m2-pwa/commit/9cf58cd5ced3e89237fc04076aa0fae3618205ef))
- **framer-next-motion:** handle resizes ([4d9c297](https://github.com/ho-nl/m2-pwa/commit/4d9c2975c7b08cfdb1c024338a8d018e22808fc6))
- **framer-next-page:** introduced SheetHeader ([dd6949f](https://github.com/ho-nl/m2-pwa/commit/dd6949fd027f6ec984f4de44fe75b36265f44906))
- **framer-next-pages:** add sheet variants top, left, bottom, right ([f0b44b4](https://github.com/ho-nl/m2-pwa/commit/f0b44b44a3c4976a35ca3235e305bd5f281f78d7))
- **framer-next-pages:** added SheetBackdrop component ([4981744](https://github.com/ho-nl/m2-pwa/commit/4981744a8bc5f74a0b7d510e0000d3070b388c79))
- **framer-next-pages:** added useCloseOverlay hook to close multiple steps at once ([55b7473](https://github.com/ho-nl/m2-pwa/commit/55b74730e64060c20072bf10f34d346964edc51f))
- **framer-next-pages:** added usePageRouter().go(-2) functionality to close overlays ([cb177e7](https://github.com/ho-nl/m2-pwa/commit/cb177e7266939b3a6a4f04c03852f024fd2dca3e))
- **framer-next-pages:** animate drag indicator when resizing height ([5b687d1](https://github.com/ho-nl/m2-pwa/commit/5b687d1cf5a04dfa2f499d1335404cd41992a7aa))
- **framer-next-pages:** animate the SheetBackdrop based on the y-value of the sheet ([96af2d4](https://github.com/ho-nl/m2-pwa/commit/96af2d4dcab87f952f9d3621a7cce9099f9310f6))
- **framer-next-pages:** base sheet on container height ([b8293e3](https://github.com/ho-nl/m2-pwa/commit/b8293e3762892529d39d3e12032d0450166ae79e))
- **framer-next-pages:** enable dragging when the content isn’t scrollable ([3df9115](https://github.com/ho-nl/m2-pwa/commit/3df9115d3fbf72dbe547780f0bc6ce80e42b9e47))
- **framer-next-pages:** implemented the FullPageShell for the remaining pages ([88386b4](https://github.com/ho-nl/m2-pwa/commit/88386b4652abb7765d6e755c7fb7a3cb6285a0e7))
- **framer-next-pages:** made all animations renderless ([7604fc0](https://github.com/ho-nl/m2-pwa/commit/7604fc037d76cefda711b7b6ccb40f14c1ef4c8e))
- **framer-next-pages:** move example to @graphcommerce/next-config ([b801856](https://github.com/ho-nl/m2-pwa/commit/b801856d370804616a986a6a66ba88ae4f193b4b))
- **framer-next-pages:** usePageDirection to determine which direction the user is navigating ([6769b90](https://github.com/ho-nl/m2-pwa/commit/6769b909486cbcc8bf58d83d13e0ef1b84a7389d))
- **framer-next-pages:** working on new sheet component ([cc6fb11](https://github.com/ho-nl/m2-pwa/commit/cc6fb11b22db59276a3ea32493bf340c02850a2c))
- **framer-sheet:** added SheetHeader component ([2cc164e](https://github.com/ho-nl/m2-pwa/commit/2cc164eac4b5022cfdf347a83ea559e26103063f))
- **framer-sheet:** created separate package that can be implemented ([69cc8ce](https://github.com/ho-nl/m2-pwa/commit/69cc8ce3237125335524728a70f4dae050032108))
- **framer-utils:** created framer-utils and implemented for framer-sheet and framer-next-pages ([788bf28](https://github.com/ho-nl/m2-pwa/commit/788bf282d4a38ec5e78ab7244065c540dfc132a1))
- **image:** introduced completely rewritten Image component ([e3413b3](https://github.com/ho-nl/m2-pwa/commit/e3413b3a57392d6571ea64cb8d9c8dca05ea31df))
- imported react-modal-sheet ([e3a76f7](https://github.com/ho-nl/m2-pwa/commit/e3a76f71a6c8f7b5cfc0766673265733040ba164))
- introduced SharedComponent to share layout between routes ([4e0f73c](https://github.com/ho-nl/m2-pwa/commit/4e0f73c5272b61806ffef1e516c453ffb9c9b0ab))
- introduces framer-next-pages and framer-sheet to next-ui and soxbase package ([e04ad8a](https://github.com/ho-nl/m2-pwa/commit/e04ad8a94cd1fd5a7c5575c9db7916b6e8a88f16))
- left and sidebar drawers ([12a3b72](https://github.com/ho-nl/m2-pwa/commit/12a3b72edfad38a4b82701ec502f2f4d85c40e53))
- next.js 11 ([7d61407](https://github.com/ho-nl/m2-pwa/commit/7d614075a778f488045034f74be4f75b93f63c43))
- **pageContext:** history prop ([9094551](https://github.com/ho-nl/m2-pwa/commit/909455146d159a839fa72046c15332fc763f315f))
- **playwright:** added new playwright package to enable browser testing ([6f49ec7](https://github.com/ho-nl/m2-pwa/commit/6f49ec7595563775b96ebf21c27e39da1282e8d9))
- renamed all packages to use [@graphcommerce](https://github.com/graphcommerce) instead of [@reachdigital](https://github.com/reachdigital) ([491e4ce](https://github.com/ho-nl/m2-pwa/commit/491e4cec9a2686472dac36b79f999257c0811ffe))
- upgraded to nextjs 11 ([0053beb](https://github.com/ho-nl/m2-pwa/commit/0053beb7ef597c190add7264256a0eaec35868da))
- **use-back-link:** go back in history when links are identical ([9be8a05](https://github.com/ho-nl/m2-pwa/commit/9be8a050d418d2ef24bb6894c5946a1268883aba))

# Change Log

All notable changes to this project will be documented in this file. See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## [2.105.5](https://github.com/ho-nl/m2-pwa/compare/@graphcommerce/framer-next-pages@2.105.4...@graphcommerce/framer-next-pages@2.105.5) (2021-09-24)

### Bug Fixes

- edit billing address updating state ([ecd9f48](https://github.com/ho-nl/m2-pwa/commit/ecd9f48ce313d8e7a698c06ff29b88231dc50168))

# [2.105.0](https://github.com/ho-nl/m2-pwa/compare/@graphcommerce/framer-next-pages@2.104.0...@graphcommerce/framer-next-pages@2.105.0) (2021-08-30)

# [2.105.0](https://github.com/ho-nl/m2-pwa/compare/@graphcommerce/framer-next-pages@2.104.0...@graphcommerce/framer-next-pages@2.105.0) (2021-08-30)

### Bug Fixes

- **use-back-link:** pop history after going back ([20d69ef](https://github.com/ho-nl/m2-pwa/commit/20d69eff868d53d07084e5d1f78819939a5f429c))

### Features

- **pageContext:** history prop ([9094551](https://github.com/ho-nl/m2-pwa/commit/909455146d159a839fa72046c15332fc763f315f))
- **use-back-link:** go back in history when links are identical ([9be8a05](https://github.com/ho-nl/m2-pwa/commit/9be8a050d418d2ef24bb6894c5946a1268883aba))

# [2.104.0](https://github.com/ho-nl/m2-pwa/compare/@graphcommerce/framer-next-pages@2.103.1...@graphcommerce/framer-next-pages@2.104.0) (2021-08-17)

### Features

- left and sidebar drawers ([12a3b72](https://github.com/ho-nl/m2-pwa/commit/12a3b72edfad38a4b82701ec502f2f4d85c40e53))

# [2.103.0](https://github.com/ho-nl/m2-pwa/compare/@graphcommerce/framer-next-pages@2.102.4...@graphcommerce/framer-next-pages@2.103.0) (2021-08-12)

### Features

- upgraded to nextjs 11 ([0053beb](https://github.com/ho-nl/m2-pwa/commit/0053beb7ef597c190add7264256a0eaec35868da))

# [2.102.0](https://github.com/ho-nl/m2-pwa/compare/@graphcommerce/framer-next-pages@2.101.2...@graphcommerce/framer-next-pages@2.102.0) (2021-07-26)

### Features

- **playwright:** added new playwright package to enable browser testing ([6f49ec7](https://github.com/ho-nl/m2-pwa/commit/6f49ec7595563775b96ebf21c27e39da1282e8d9))

## [2.101.2](https://github.com/ho-nl/m2-pwa/compare/@graphcommerce/framer-next-pages@2.101.1...@graphcommerce/framer-next-pages@2.101.2) (2021-07-23)

### Bug Fixes

- **app-shell-header:** offset not always correctly set ([11a8907](https://github.com/ho-nl/m2-pwa/commit/11a890764be1ab4f6c584a5c8ca4e6620d0d73e5))

# [2.101.0](https://github.com/ho-nl/m2-pwa/compare/@graphcommerce/framer-next-pages@2.100.10...@graphcommerce/framer-next-pages@2.101.0) (2021-07-20)

### Bug Fixes

- back button behavior ([59f7b20](https://github.com/ho-nl/m2-pwa/commit/59f7b2047194c3506037fc88d791302c7c4a1a69))
- **framer-next-pages:** back navigation renders the wrong page, items were reversed ([7168fc1](https://github.com/ho-nl/m2-pwa/commit/7168fc1d1daa3920ae401dda0029e35a253068ec))
- **framer-next-pages:** backSteps returns NaN ([31ac95a](https://github.com/ho-nl/m2-pwa/commit/31ac95a75fb166efdc2d52d0aa0e40e45290e6bb))
- **framer-next-pages:** fix closing of overlay in example ([049a9a7](https://github.com/ho-nl/m2-pwa/commit/049a9a79f882bcf6251fc24cb395b88418349557))
- **framer-next-pages:** stacking order becomes reversed ([65bda4e](https://github.com/ho-nl/m2-pwa/commit/65bda4e8df199d805da6edc12ba61badf56eac8f))
- ignore md files from triggering version updates ([4f98392](https://github.com/ho-nl/m2-pwa/commit/4f9839250b3a32d3070da5290e5efcc5e2243fba))

### Features

- content header component ([9cf58cd](https://github.com/ho-nl/m2-pwa/commit/9cf58cd5ced3e89237fc04076aa0fae3618205ef))
