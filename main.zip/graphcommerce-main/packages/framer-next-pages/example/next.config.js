/* eslint-disable @typescript-eslint/no-var-requires */

const withGraphCommerce = require('@graphcommerce/next-config').withYarn1Scopes()

module.exports = withGraphCommerce({
  experimental: {
    scrollRestoration: true,
  },
})
