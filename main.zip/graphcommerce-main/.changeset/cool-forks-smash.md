---
"@graphcommerce/next-ui": patch
"@graphcommerce/magento-graphcms": patch
---

show globe icon instead of shopping bag icon for store/language-switcher
